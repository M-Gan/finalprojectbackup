<?php
/**
 * Title: Bloggery Team 1
 * Slug: bloggery/sonoran-team-001
 * Categories: teams
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|superbspacing-xxlarge","bottom":"var:preset|spacing|superbspacing-xxlarge","left":"var:preset|spacing|superbspacing-small","right":"var:preset|spacing|superbspacing-small"},"blockGap":"var:preset|spacing|superbspacing-large","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--superbspacing-xxlarge);padding-right:var(--wp--preset--spacing--superbspacing-small);padding-bottom:var(--wp--preset--spacing--superbspacing-xxlarge);padding-left:var(--wp--preset--spacing--superbspacing-small)"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xxsmall"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"textAlign":"left","level":3,"textColor":"primary","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-left has-primary-color has-text-color has-superbfont-small-font-size">A talented team</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","textColor":"contrast","fontSize":"superbfont-xlarge"} -->
<h2 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xlarge-font-size">Meet Our Team</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","textColor":"secondary","fontSize":"superbfont-small"} -->
<p class="has-text-align-center has-secondary-color has-text-color has-superbfont-small-font-size">Get to know the talented indivisuals behind our blog.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|superbspacing-xlarge","left":"var:preset|spacing|superbspacing-small"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image aligncenter size-large has-custom-border"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . "/assets/images/sonoran-team1.jpg");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","level":3,"textColor":"contrast","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-small-font-size">Mike Johnson</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"400"}},"textColor":"contrast","fontSize":"superbfont-xsmall"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xsmall-font-size" style="font-style:normal;font-weight:400">Editor</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","textColor":"secondary","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-center has-secondary-color has-text-color has-superbfont-xsmall-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non nisl in velit dignissim mollis a rhoncus dolor.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"primary","iconColorValue":"#5850EC","align":"center","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links aligncenter has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"https://linkedin.com","service":"linkedin"} /-->

<!-- wp:social-link {"url":"https://facebook.com","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://instagram.com","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image aligncenter size-large has-custom-border"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . "/assets/images/sonoran-team2.jpg");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","level":3,"textColor":"contrast","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-small-font-size">Sarah Davis</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"400"}},"textColor":"contrast","fontSize":"superbfont-xsmall"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xsmall-font-size" style="font-style:normal;font-weight:400">Writer</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","textColor":"secondary","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-center has-secondary-color has-text-color has-superbfont-xsmall-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non nisl in velit dignissim mollis a rhoncus dolor.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"primary","iconColorValue":"#5850EC","align":"center","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links aligncenter has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"https://linkedin.com","service":"linkedin"} /-->

<!-- wp:social-link {"url":"https://facebook.com","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://instagram.com","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image aligncenter size-large has-custom-border"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . "/assets/images/sonoran-team3.jpg");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","level":3,"textColor":"contrast","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-small-font-size">Jane Smith</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"400"}},"textColor":"contrast","fontSize":"superbfont-xsmall"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xsmall-font-size" style="font-style:normal;font-weight:400">CEO</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","textColor":"secondary","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-center has-secondary-color has-text-color has-superbfont-xsmall-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non nisl in velit dignissim mollis a rhoncus dolor.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"primary","iconColorValue":"#5850EC","align":"center","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links aligncenter has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"https://linkedin.com","service":"linkedin"} /-->

<!-- wp:social-link {"url":"https://facebook.com","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://instagram.com","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image aligncenter size-large has-custom-border"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . "/assets/images/sonoran-team4.jpg");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","level":3,"textColor":"contrast","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-small-font-size">David Thompson</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"400"}},"textColor":"contrast","fontSize":"superbfont-xsmall"} -->
<h3 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xsmall-font-size" style="font-style:normal;font-weight:400">Marketing Specialist</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","textColor":"secondary","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-center has-secondary-color has-text-color has-superbfont-xsmall-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non nisl in velit dignissim mollis a rhoncus dolor.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"primary","iconColorValue":"#5850EC","align":"center","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links aligncenter has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"https://linkedin.com","service":"linkedin"} /-->

<!-- wp:social-link {"url":"https://facebook.com","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://instagram.com","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->