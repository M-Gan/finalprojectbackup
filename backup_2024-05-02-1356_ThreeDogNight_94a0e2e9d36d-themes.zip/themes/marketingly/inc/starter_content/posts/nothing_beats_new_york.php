<?php
return array(
    'post_type'    => 'post',
    'post_name'    => 'nothing-breaks-new-york',
    'post_title'   => 'Nothing Beats New York',
    'thumbnail' => '{{featured-image-nothing-breaks-new-york}}',
    'post_content' => '
<!-- wp:paragraph -->
<p>Etiam placerat velit vitae dui blandit sollicitudin. Vestibulum tincidunt sed dolor sit amet volutpat. Nullam egestas sem at mollis sodales. Nunc eget lacinia eros, ut tincidunt nunc. Quisque volutpat, enim id volutpat interdum, purus odio euismod neque, sit amet faucibus justo dolor tincidunt dui. Nulla facilisi. Phasellus in tincidunt lacus, in gravida ipsum. Cras id vehicula est, tincidunt pellentesque magna. Etiam porttitor nulla urna, quis vulputate justo euismod ac. Nunc viverra sollicitudin fringilla.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Ut a tortor quis nunc mattis placerat vitae sed sapien. Duis vitae enim ac turpis viverra ullamcorper et vitae odio. Pellentesque arcu tortor, aliquam vel semper at, ullamcorper et odio. Nullam aliquet rhoncus quam non iaculis. Pellentesque id enim et nisl ultricies vulputate in a magna. Ut lectus eros, imperdiet at ultricies interdum, ornare sit amet massa. Suspendisse tempus neque ut congue aliquam.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Maecenas felis lacus, mollis eu tellus vitae, tincidunt sodales elit. Fusce placerat ante eget sapien egestas, eu eleifend turpis aliquet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Ut id quam sed mauris bibendum convallis. Maecenas erat dui, ultricies id sem quis, maximus accumsan enim. Pellentesque porta, purus sit amet imperdiet blandit, quam eros porta orci, eu placerat quam libero a tortor. Cras convallis tellus id sapien congue sollicitudin. Aenean vehicula lacus vel ligula aliquam, sit amet auctor felis pharetra. Maecenas id nisi velit. Pellentesque mattis ligula leo, id bibendum ligula mollis at. Donec ornare hendrerit est at finibus. Phasellus in ante id nulla pharetra ullamcorper.</p>
<!-- /wp:paragraph -->'
);
